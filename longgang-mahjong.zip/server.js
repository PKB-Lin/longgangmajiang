const http = require('http');
const fs = require('fs');
const path = require('path');
const { WebSocketServer } = require('ws');

// ============ 常量 ============
const TILE_NAMES = [
  '1万','2万','3万','4万','5万','6万','7万','8万','9万',        // 0-8
  '1条','2条','3条','4条','5条','6条','7条','8条','9条',        // 9-17
  '1筒','2筒','3筒','4筒','5筒','6筒','7筒','8筒','9筒',        // 18-26
  '东','南','西','北','中','发','白'                               // 27-33
];

const TOTAL_TILES = 136; // 34种 × 4张
const HAND_SIZE = 16;    // 每人16张（庄家17张）
const PLAYER_COUNT = 4;

// ============ 麻将引擎 ============
class MahjongEngine {

  // 生成并洗牌
  static createWall() {
    const wall = [];
    for (let i = 0; i < 34; i++) {
      for (let j = 0; j < 4; j++) wall.push(i);
    }
    // Fisher-Yates shuffle
    for (let i = wall.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [wall[i], wall[j]] = [wall[j], wall[i]];
    }
    return wall;
  }

  // 发牌
  static deal(wall) {
    const hands = [[], [], [], []];
    // 每人16张，庄家17张（最后一张）
    for (let i = 0; i < HAND_SIZE; i++) {
      for (let p = 0; p < PLAYER_COUNT; p++) {
        hands[p].push(wall.pop());
      }
    }
    // 庄家多摸一张
    hands[0].push(wall.pop());
    // 排序
    hands.forEach(h => h.sort((a, b) => a - b));
    return hands;
  }

  // 从牌墙摸牌
  static draw(wall) {
    return wall.pop();
  }

  // 排序手牌
  static sortHand(hand) {
    hand.sort((a, b) => a - b);
  }

  // 检查是否可以吃牌（上家的牌 + 手牌中的两张组成顺子）
  static canChi(hand, tile) {
    if (tile >= 27) return []; // 字牌不能吃
    const suit = Math.floor(tile / 9);
    const num = tile % 9;
    const results = [];
    // 尝试三种组合
    const combos = [
      [tile - 2, tile - 1], // X-2, X-1, X
      [tile - 1, tile + 1], // X-1, X, X+1
      [tile + 1, tile + 2], // X, X+1, X+2
    ];
    for (const [a, b] of combos) {
      if (a < 0 || b >= 34) continue;
      if (Math.floor(a / 9) !== suit || Math.floor(b / 9) !== suit) continue;
      const countA = hand.filter(t => t === a).length;
      const countB = hand.filter(t => t === b).length;
      if (countA > 0 && countB > 0) {
        results.push([a, b]);
      }
    }
    return results;
  }

  // 检查是否可以碰牌
  static canPong(hand, tile) {
    const count = hand.filter(t => t === tile).length;
    return count >= 2;
  }

  // 检查是否可以明杠
  static canMingKong(hand, tile) {
    const count = hand.filter(t => t === tile).length;
    return count >= 3;
  }

  // 检查是否可以暗杠（手中有4张相同）
  static canAnKong(hand) {
    const counts = {};
    for (const t of hand) counts[t] = (counts[t] || 0) + 1;
    return Object.entries(counts).filter(([, c]) => c === 4).map(([t]) => parseInt(t));
  }

  // 检查是否可以加杠（已碰的牌，手中还有一张）
  static canJiaKong(hand, melds, tile) {
    // 检查是否有碰过的该牌
    const hasPong = melds.some(m => m.type === 'pong' && m.tile === tile);
    if (!hasPong) return false;
    return hand.includes(tile);
  }

  // 胡牌检测 - 核心算法
  // 手牌应该是 3n+2 张（14, 17等）
  static canWin(hand) {
    const sorted = [...hand].sort((a, b) => a - b);
    const counts = {};
    for (const t of sorted) counts[t] = (counts[t] || 0) + 1;

    // 尝试每种可能的将牌
    for (const tile of Object.keys(counts).map(Number)) {
      if (counts[tile] >= 2) {
        const remaining = {};
        for (const [t, c] of Object.entries(counts)) {
          remaining[t] = c;
        }
        remaining[tile] -= 2;
        if (MahjongEngine._canFormMelds(remaining)) {
          return true;
        }
      }
    }
    return false;
  }

  // 递归检测是否能组成顺子/刻子
  static _canFormMelds(counts) {
    // 找到第一个非零的牌
    let first = null;
    for (const [t, c] of Object.entries(counts)) {
      if (c > 0) { first = parseInt(t); break; }
    }
    if (first === null) return true; // 所有牌都处理完了

    // 尝试刻子
    if (counts[first] >= 3) {
      counts[first] -= 3;
      if (MahjongEngine._canFormMelds(counts)) return true;
      counts[first] += 3;
    }

    // 尝试顺子（仅万/条/筒）
    if (first < 27) {
      const suit = Math.floor(first / 9);
      const num = first % 9;
      if (num <= 6) {
        const second = first + 1;
        const third = first + 2;
        if (Math.floor(second / 9) === suit && Math.floor(third / 9) === suit &&
            (counts[second] || 0) > 0 && (counts[third] || 0) > 0) {
          counts[first]--;
          counts[second]--;
          counts[third]--;
          if (MahjongEngine._canFormMelds(counts)) return true;
          counts[first]++;
          counts[second]++;
          counts[third]++;
        }
      }
    }

    return false;
  }

  // 计算龙港麻将台数
  // hand: 胡牌时的完整手牌（包括最后摸/吃到的牌，即3n+2=17张 for 16-tile）
  // melds: 已吃碰杠的副露 [{[tile], type: 'chi'|'pong'|'kong'}]
  // isSelfDraw: 是否自摸
  // prevailingWind: 场风
  // seatWind: 座位风
  static calculateTai(hand, melds, isSelfDraw, options = {}) {
    let tai = 0;

    // 平胡基础1台
    tai += 1;

    // 自摸 +1台
    if (isSelfDraw) tai += 1;

    // 获取所有牌（手牌 + 副露）
    const allTiles = [...hand];
    for (const m of melds) {
      if (m.type === 'chi') {
        allTiles.push(...m.tiles);
      } else if (m.type === 'pong') {
        allTiles.push(m.tile, m.tile, m.tile);
      } else if (m.type === 'kong') {
        allTiles.push(m.tile, m.tile, m.tile, m.tile);
      }
    }

    // 碰碰胡 - 全部由刻子组成（没有顺子副露）
    const hasChi = melds.some(m => m.type === 'chi');
    if (!hasChi) tai += 1;

    // 清一色 - 全部同一种花色
    const suits = new Set();
    for (const t of allTiles) {
      if (t < 27) suits.add(Math.floor(t / 9));
      else suits.add(3); // 字牌
    }
    if (suits.size === 1 && !suits.has(3)) tai += 2;

    // 混一色 - 一种花色 + 字牌
    if (suits.size === 2 && suits.has(3)) tai += 1;

    // 无字牌
    if (!allTiles.some(t => t >= 27)) tai += 0;

    return tai;
  }

  // 获取牌的花色 0=万 1=条 2=筒 3=字
  static getSuit(tile) {
    if (tile < 9) return 0;
    if (tile < 18) return 1;
    if (tile < 27) return 2;
    return 3;
  }
}

// ============ 房间管理 ============
class RoomManager {
  constructor() {
    this.rooms = new Map();
    this.playerRooms = new Map(); // ws -> roomId
  }

  createRoom() {
    const id = this._generateId();
    const room = new GameRoom(id);
    this.rooms.set(id, room);
    console.log(`Room ${id} created`);
    return room;
  }

  getRoom(id) {
    return this.rooms.get(id);
  }

  joinRoom(roomId, playerId, playerName, ws) {
    const room = this.rooms.get(roomId);
    if (!room) return { error: '房间不存在' };
    const result = room.addPlayer(playerId, playerName, ws);
    if (result.error) return result;
    this.playerRooms.set(ws, roomId);
    return { success: true, room };
  }

  leaveRoom(ws) {
    const roomId = this.playerRooms.get(ws);
    if (!roomId) return;
    const room = this.rooms.get(roomId);
    if (room) room.removePlayer(ws);
    this.playerRooms.delete(ws);
    if (room && room.players.length === 0) {
      this.rooms.delete(roomId);
      console.log(`Room ${roomId} deleted (empty)`);
    }
  }

  _generateId() {
    return Math.random().toString(36).substring(2, 6).toUpperCase();
  }
}

// ============ 游戏房间 ============
class GameRoom {
  constructor(id) {
    this.id = id;
    this.players = [];          // [{id, name, ws, seat, hand, melds, ready}]
    this.state = 'waiting';     // waiting | playing | finished
    this.wall = [];
    this.currentTurn = -1;
    this.dealerSeat = 0;
    this.lastDiscard = null;    // {tile, seat}
    this.turnCount = 0;
    this.prevailingWind = 0;    // 场风 0=东
  }

  addPlayer(playerId, playerName, ws) {
    if (this.players.length >= PLAYER_COUNT) return { error: '房间已满' };
    if (this.state !== 'waiting') return { error: '游戏已开始' };
    if (this.players.find(p => p.id === playerId)) return { error: '已在房间中' };

    const seat = this.players.length;
    this.players.push({
      id: playerId,
      name: playerName,
      ws,
      seat,
      hand: [],
      melds: [],
      ready: false,
      score: 0,
    });

    this._broadcast({ type: 'room_update', players: this._getPlayerInfo(), roomId: this.id });
    return { success: true };
  }

  removePlayer(ws) {
    const idx = this.players.findIndex(p => p.ws === ws);
    if (idx >= 0) {
      const p = this.players[idx];
      this.players.splice(idx, 1);
      // 重新分配座位
      this.players.forEach((p, i) => p.seat = i);
      this._broadcast({ type: 'room_update', players: this._getPlayerInfo(), roomId: this.id });
    }
  }

  // 设置准备状态
  setReady(ws, ready) {
    const player = this.players.find(p => p.ws === ws);
    if (!player) return;
    player.ready = ready;
    this._broadcast({ type: 'player_ready', seat: player.seat, ready });

    // 所有人准备好，开始游戏
    if (this.players.length >= 2 && this.players.every(p => p.ready)) {
      this.startGame();
    }
  }

  // 开始游戏
  startGame() {
    this.state = 'playing';
    this.wall = MahjongEngine.createWall();
    const hands = MahjongEngine.deal(this.wall);

    // 直接给每个玩家分配手牌（按座位顺序）
    for (let i = 0; i < this.players.length; i++) {
      this.players[i].hand = hands[i] || [];
    }

    // 庄家（座0）先出牌
    this.currentTurn = this.dealerSeat;
    this.lastDiscard = null;

    // 发送游戏开始，每人只看到自己的手牌
    for (const player of this.players) {
      this._sendTo(player.ws, {
        type: 'game_start',
        hand: player.hand,
        seat: player.seat,
        dealerSeat: this.dealerSeat,
        currentTurn: this.currentTurn,
        players: this._getPlayerInfo(),
        remainingTiles: this.wall.length,
      });
    }

    // 庄家需要先出牌
    const dealer = this.players[this.dealerSeat];
    if (dealer) {
      // 检查庄家是否可以暗杠/自摸
      const actions = [];
      if (MahjongEngine.canWin(dealer.hand)) actions.push('win');
      if (MahjongEngine.canAnKong(dealer.hand).length > 0) actions.push('ankong');
      for (const m of dealer.melds) {
        if (m.type === 'pong' && dealer.hand.includes(m.tile)) {
          actions.push('jiakong');
          break;
        }
      }
      if (actions.length > 0) {
        this._sendTo(dealer.ws, {
          type: 'action_prompt',
          actions,
          timeout: 8000,
        });
        this._actionTimeout = setTimeout(() => {
          this._sendTo(dealer.ws, { type: 'need_discard' });
        }, 8000);
      } else {
        this._sendTo(dealer.ws, { type: 'need_discard' });
      }
    }

    console.log(`Game started in room ${this.id}`);
  }

  // 玩家操作：出牌
  discard(ws, tile) {
    const player = this.players.find(p => p.ws === ws);
    if (!player || player.seat !== this.currentTurn) return;

    const idx = player.hand.indexOf(tile);
    if (idx === -1) return;

    player.hand.splice(idx, 1);
    MahjongEngine.sortHand(player.hand);
    this.lastDiscard = { tile, seat: player.seat };

    // 广播给其他人
    this._broadcast({
      type: 'discard',
      seat: player.seat,
      tile,
      handCount: player.hand.length,
    }, ws);

    // 给出牌者本人发送手牌更新
    this._sendTo(ws, {
      type: 'discard_self',
      tile,
      hand: player.hand,
    });

    // 检查其他玩家是否可以吃碰杠胡
    this._checkActions(tile, player.seat);
  }

  // 检查其他玩家对刚打出的牌的操作
  _checkActions(tile, discardSeat) {
    const actions = {};
    const numPlayers = this.players.length;
    const nextTurn = (discardSeat + 1) % numPlayers;

    for (let i = 1; i < numPlayers; i++) {
      const seat = (discardSeat + i) % numPlayers;
      const player = this.players[seat];
      if (!player) continue;

      const playerActions = [];

      // 胡牌检测
      const testHand = [...player.hand, tile];
      if (MahjongEngine.canWin(testHand)) {
        playerActions.push('win');
      }

      // 杠牌检测
      if (MahjongEngine.canMingKong(player.hand, tile)) {
        playerActions.push('kong');
      }

      // 碰牌检测（所有其他玩家都可以碰）
      if (MahjongEngine.canPong(player.hand, tile)) {
        playerActions.push('pong');
      }

      // 吃牌检测（只有下家 i===1）
      if (i === 1) {
        const chiOptions = MahjongEngine.canChi(player.hand, tile);
        if (chiOptions.length > 0) {
          playerActions.push('chi');
          // 保存吃牌选项供后续使用
          player._chiOptions = chiOptions;
        }
      }

      if (playerActions.length > 0) {
        actions[seat] = playerActions;
      }
    }

    if (Object.keys(actions).length > 0) {
      // 记录待操作状态
      this._pendingActions = actions;
      this._passedSeats = new Set();
      this._actionSeat = discardSeat;

      // 有玩家可以操作，发送给他们
      for (const [seat, acts] of Object.entries(actions)) {
        const player = this.players[parseInt(seat)];
        if (player) {
          this._sendTo(player.ws, {
            type: 'action_prompt',
            tile,
            fromSeat: discardSeat,
            actions: acts,
            timeout: 15000,
          });
        }
      }
      // 设置超时：超时后自动让所有人过
      this._actionTimeout = setTimeout(() => {
        this._autoDraw(nextTurn);
      }, 15000);
    } else {
      // 没人可以操作，下家摸牌
      this._autoDraw(nextTurn);
    }
  }

  // 玩家确认操作（吃/碰/杠/胡）
  confirmAction(ws, action, chiTiles) {
    const player = this.players.find(p => p.ws === ws);
    if (!player || !this.lastDiscard) return;

    clearTimeout(this._actionTimeout);
    const tile = this.lastDiscard.tile;

    switch (action) {
      case 'win':
        this._handleWin(player, tile, false);
        break;
      case 'pong':
        this._handlePong(player, tile);
        break;
      case 'kong':
        this._handleKong(player, tile);
        break;
      case 'chi':
        // 自动选择第一个可用的吃牌组合
        const options = player._chiOptions || MahjongEngine.canChi(player.hand, tile);
        this._handleChi(player, tile, options[0]);
        break;
      case 'pass':
        this._handlePass(player.seat);
        break;
    }
  }

  _handleWin(player, tile, isSelfDraw) {
    const hand = isSelfDraw ? [...player.hand] : [...player.hand, tile];
    const tai = MahjongEngine.calculateTai(hand, player.melds, isSelfDraw);

    this.state = 'finished';

    this._broadcast({
      type: 'game_win',
      winnerSeat: player.seat,
      winnerName: player.name,
      isSelfDraw,
      hand: player.hand,
      melds: player.melds,
      finalTile: tile,
      tai,
    });
  }

  _handlePong(player, tile) {
    // 从手牌移除两张
    for (let i = 0; i < 2; i++) {
      const idx = player.hand.indexOf(tile);
      player.hand.splice(idx, 1);
    }
    player.melds.push({ type: 'pong', tile });
    this.lastDiscard = null;
    this.currentTurn = player.seat;

    this._broadcast({
      type: 'pong_result',
      seat: player.seat,
      tile,
      handCount: player.hand.length,
    });

    // 给碰牌者本人发送手牌更新
    this._sendTo(player.ws, {
      type: 'meld_update',
      hand: player.hand,
      melds: player.melds,
    });

    // 碰牌后需要再出一张
    this._sendTo(player.ws, { type: 'need_discard' });
  }

  _handleKong(player, tile) {
    // 从手牌移除三张
    for (let i = 0; i < 3; i++) {
      const idx = player.hand.indexOf(tile);
      player.hand.splice(idx, 1);
    }
    player.melds.push({ type: 'kong', tile });

    // 杠后补牌
    const newTile = MahjongEngine.draw(this.wall);
    player.hand.push(newTile);
    MahjongEngine.sortHand(player.hand);

    this.lastDiscard = null;
    this.currentTurn = player.seat;

    this._broadcast({
      type: 'kong_result',
      seat: player.seat,
      tile,
      handCount: player.hand.length,
      remainingTiles: this.wall.length,
    });

    // 给杠牌者本人发送手牌更新
    this._sendTo(player.ws, {
      type: 'meld_update',
      hand: player.hand,
      melds: player.melds,
    });

    // 检查杠上开花
    if (MahjongEngine.canWin(player.hand)) {
      this._sendTo(player.ws, {
        type: 'action_prompt',
        tile: newTile,
        fromSeat: player.seat,
        actions: ['win'],
        timeout: 5000,
      });
    } else {
      this._sendTo(player.ws, { type: 'need_discard' });
    }
  }

  _handleChi(player, tile, chiTiles) {
    if (!chiTiles || chiTiles.length !== 2) return;
    // 从手牌移除两张
    for (const ct of chiTiles) {
      const idx = player.hand.indexOf(ct);
      if (idx >= 0) player.hand.splice(idx, 1);
    }
    player.melds.push({ type: 'chi', tiles: [chiTiles[0], chiTiles[1], tile].sort((a, b) => a - b) });
    this.lastDiscard = null;
    this.currentTurn = player.seat;

    this._broadcast({
      type: 'chi_result',
      seat: player.seat,
      tiles: [chiTiles[0], chiTiles[1], tile].sort((a, b) => a - b),
      handCount: player.hand.length,
    });

    // 给吃牌者本人发送手牌更新
    this._sendTo(player.ws, {
      type: 'meld_update',
      hand: player.hand,
      melds: player.melds,
    });

    this._sendTo(player.ws, { type: 'need_discard' });
  }

  _handlePass(seat) {
    // 记录该玩家已过
    if (this._passedSeats) this._passedSeats.add(seat);

    // 检查是否所有待操作玩家都已过
    if (this._pendingActions) {
      const allPassed = Object.keys(this._pendingActions).every(s =>
        this._passedSeats.has(parseInt(s))
      );
      if (!allPassed) return; // 还有其他人在操作，等待
    }

    // 所有人都过了，下家摸牌
    const numPlayers = this.players.length;
    const nextTurn = (this._actionSeat !== undefined ? this._actionSeat : this.lastDiscard.seat) + 1;
    this._pendingActions = null;
    this._passedSeats = null;
    this._autoDraw(nextTurn % numPlayers);
  }

  // 自动摸牌
  _autoDraw(seat) {
    clearTimeout(this._actionTimeout);
    this.lastDiscard = null;

    if (this.wall.length === 0) {
      // 荒庄
      this._broadcast({ type: 'game_draw' });
      this.state = 'finished';
      return;
    }

    const player = this.players[seat];
    if (!player) return;

    const tile = MahjongEngine.draw(this.wall);
    player.hand.push(tile);
    MahjongEngine.sortHand(player.hand);
    this.currentTurn = seat;

    this._broadcast({
      type: 'draw',
      seat,
      handCount: player.hand.length,
      remainingTiles: this.wall.length,
    });

    // 发送摸到的牌给该玩家
    this._sendTo(player.ws, {
      type: 'your_draw',
      tile,
      hand: player.hand,
      handCount: player.hand.length,
    });

    // 检查是否可以自摸/暗杠/加杠
    const actions = [];
    if (MahjongEngine.canWin(player.hand)) actions.push('win');
    if (MahjongEngine.canAnKong(player.hand).length > 0) actions.push('ankong');
    for (const m of player.melds) {
      if (m.type === 'pong' && player.hand.includes(m.tile)) {
        actions.push('jiakong');
        break;
      }
    }

    if (actions.length > 0) {
      this._sendTo(player.ws, {
        type: 'action_prompt',
        actions,
        timeout: 8000,
      });
      this._actionTimeout = setTimeout(() => {
        this._sendTo(player.ws, { type: 'need_discard' });
      }, 8000);
    } else {
      this._sendTo(player.ws, { type: 'need_discard' });
    }
  }

  // 玩家自己的操作（暗杠/加杠/自摸等）
  playerOwnAction(ws, action, tile) {
    const player = this.players.find(p => p.ws === ws);
    if (!player || player.seat !== this.currentTurn) return;

    clearTimeout(this._actionTimeout);

    switch (action) {
      case 'win':
        this._handleWin(player, null, true);
        break;
      case 'ankong':
        this._handleAnKong(player, tile);
        break;
      case 'jiakong':
        this._handleJiaKong(player, tile);
        break;
      case 'discard_now':
        // 玩家选择不出牌（跳过自摸/暗杠），直接让他出牌
        this._sendTo(ws, { type: 'need_discard' });
        break;
    }
  }

  _handleAnKong(player, tile) {
    // 从手牌移除四张
    for (let i = 0; i < 4; i++) {
      const idx = player.hand.indexOf(tile);
      player.hand.splice(idx, 1);
    }
    player.melds.push({ type: 'kong', tile, hidden: true });

    // 杠后补牌
    const newTile = MahjongEngine.draw(this.wall);
    player.hand.push(newTile);
    MahjongEngine.sortHand(player.hand);

    this._broadcast({
      type: 'ankong_result',
      seat: player.seat,
      handCount: player.hand.length,
      remainingTiles: this.wall.length,
    });

    // 给暗杠者本人发送手牌更新
    this._sendTo(player.ws, {
      type: 'meld_update',
      hand: player.hand,
      melds: player.melds,
    });

    // 检查杠上开花
    if (MahjongEngine.canWin(player.hand)) {
      this._sendTo(player.ws, {
        type: 'action_prompt',
        actions: ['win'],
        timeout: 5000,
      });
    } else {
      this._sendTo(player.ws, { type: 'need_discard' });
    }
  }

  _handleJiaKong(player, tile) {
    // 找到碰的副露并改为杠
    const meld = player.melds.find(m => m.type === 'pong' && m.tile === tile);
    if (!meld) return;
    meld.type = 'kong';

    // 从手牌移除一张
    const idx = player.hand.indexOf(tile);
    player.hand.splice(idx, 1);

    // 杠后补牌
    const newTile = MahjongEngine.draw(this.wall);
    player.hand.push(newTile);
    MahjongEngine.sortHand(player.hand);

    this._broadcast({
      type: 'jiakong_result',
      seat: player.seat,
      tile,
      handCount: player.hand.length,
      remainingTiles: this.wall.length,
    });

    // 给加杠者本人发送手牌更新
    this._sendTo(player.ws, {
      type: 'meld_update',
      hand: player.hand,
      melds: player.melds,
    });

    if (MahjongEngine.canWin(player.hand)) {
      this._sendTo(player.ws, {
        type: 'action_prompt',
        actions: ['win'],
        timeout: 5000,
      });
    } else {
      this._sendTo(player.ws, { type: 'need_discard' });
    }
  }

  _getPlayerInfo() {
    return this.players.map(p => ({
      seat: p.seat,
      name: p.name,
      ready: p.ready,
      handCount: p.hand.length,
      meldCount: p.melds.length,
      score: p.score,
    }));
  }

  _broadcast(data, excludeWs) {
    const msg = JSON.stringify(data);
    for (const player of this.players) {
      if (player.ws !== excludeWs && player.ws.readyState === 1) {
        player.ws.send(msg);
      }
    }
  }

  _sendTo(ws, data) {
    if (ws.readyState === 1) {
      ws.send(JSON.stringify(data));
    }
  }
}

// ============ HTTP + WebSocket 服务器 ============
const PORT = process.env.PORT || 3456;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
};

const server = http.createServer((req, res) => {
  let filePath = req.url === '/' ? '/index.html' : req.url;
  filePath = path.join(__dirname, 'public', filePath);

  const ext = path.extname(filePath);
  const contentType = MIME[ext] || 'application/octet-stream';

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404);
      res.end('Not Found');
      return;
    }
    res.writeHead(200, { 'Content-Type': contentType });
    res.end(data);
  });
});

const wss = new WebSocketServer({ server });
const roomManager = new RoomManager();

// 生成玩家ID
function generatePlayerId() {
  return 'p_' + Math.random().toString(36).substring(2, 10);
}

wss.on('connection', (ws) => {
  const playerId = generatePlayerId();
  let playerName = '';

  ws.on('message', (data) => {
    try {
      const msg = JSON.parse(data.toString());

      switch (msg.type) {
        case 'create_room': {
          const room = roomManager.createRoom();
          // 创建者自动加入房间
          playerName = msg.name || '房主';
          const joinResult = room.addPlayer(playerId, playerName, ws);
          roomManager.playerRooms.set(ws, room.id);
          ws.send(JSON.stringify({
            type: 'room_created',
            roomId: room.id,
            seat: 0,
            players: room._getPlayerInfo(),
          }));
          break;
        }

        case 'join_room': {
          playerName = msg.name || '玩家';
          const result = roomManager.joinRoom(msg.roomId, playerId, playerName, ws);
          if (result.error) {
            ws.send(JSON.stringify({ type: 'error', message: result.error }));
          } else {
            ws.send(JSON.stringify({
              type: 'room_joined',
              roomId: msg.roomId,
              seat: result.room.players.length - 1,
              players: result.room._getPlayerInfo(),
            }));
          }
          break;
        }

        case 'set_ready': {
          roomManager.playerRooms.has(ws) && 
            roomManager.getRoom(roomManager.playerRooms.get(ws))
              ?.setReady(ws, msg.ready);
          break;
        }

        case 'discard': {
          roomManager.playerRooms.has(ws) &&
            roomManager.getRoom(roomManager.playerRooms.get(ws))
              ?.discard(ws, msg.tile);
          break;
        }

        case 'action': {
          roomManager.playerRooms.has(ws) &&
            roomManager.getRoom(roomManager.playerRooms.get(ws))
              ?.confirmAction(ws, msg.action, msg.chiTiles);
          break;
        }

        case 'own_action': {
          roomManager.playerRooms.has(ws) &&
            roomManager.getRoom(roomManager.playerRooms.get(ws))
              ?.playerOwnAction(ws, msg.action, msg.tile);
          break;
        }

        case 'leave_room': {
          roomManager.leaveRoom(ws);
          ws.send(JSON.stringify({ type: 'room_left' }));
          break;
        }
      }
    } catch (e) {
      console.error('Message error:', e);
    }
  });

  ws.on('close', () => {
    roomManager.leaveRoom(ws);
  });

  ws.send(JSON.stringify({ type: 'connected', playerId }));
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`龙港麻将服务器已启动: http://localhost:${PORT}`);
});
