// tiles.js - 麻将牌 SVG 图案生成

var CN_NUMS = ['一', '二', '三', '四', '五', '六', '七', '八', '九'];

// 筒位 (viewBox 0 0 40 54)
var DOT_POS = {
  1: [[20, 27]],
  2: [[20, 16], [20, 38]],
  3: [[12, 13], [20, 27], [28, 41]],
  4: [[13, 16], [27, 16], [13, 38], [27, 38]],
  5: [[13, 14], [27, 14], [20, 27], [13, 40], [27, 40]],
  6: [[13, 13], [27, 13], [13, 27], [27, 27], [13, 41], [27, 41]],
  7: [[20, 10], [13, 21], [27, 21], [13, 32], [27, 32], [13, 43], [27, 43]],
  8: [[13, 10], [27, 10], [13, 21], [27, 21], [13, 33], [27, 33], [13, 44], [27, 44]],
  9: [[13, 10], [20, 10], [27, 10], [13, 23], [20, 23], [27, 23], [13, 36], [20, 36], [27, 36]]
};

// 条位
var BAMBOO_POS = {
  2: [[20, 14], [20, 36]],
  3: [[20, 12], [12, 28], [28, 38]],
  4: [[13, 14], [27, 14], [13, 36], [27, 36]],
  5: [[13, 12], [27, 12], [20, 24], [13, 36], [27, 36]],
  6: [[13, 12], [27, 12], [13, 24], [27, 24], [13, 36], [27, 36]],
  7: [[20, 10], [13, 21], [27, 21], [13, 32], [27, 32], [13, 43], [27, 43]],
  8: [[13, 10], [27, 10], [13, 21], [27, 21], [13, 33], [27, 33], [13, 44], [27, 44]],
  9: [[13, 10], [20, 10], [27, 10], [13, 23], [20, 23], [27, 23], [13, 36], [20, 36], [27, 36]]
};

function getTileSVGContent(tile) {
  if (tile < 9) return _wanSVG(tile + 1);
  if (tile < 18) return _tiaoSVG(tile - 8);
  if (tile < 27) return _tongSVG(tile - 17);
  return _ziSVG(tile - 27);
}

function tileSVG(tile) {
  return '<svg viewBox="0 0 40 54" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid meet" style="width:100%;height:100%;display:block;pointer-events:none;">' + getTileSVGContent(tile) + '</svg>';
}

// ========== 万 ==========
function _wanSVG(num) {
  var n = CN_NUMS[num - 1];
  return '<text x="20" y="23" text-anchor="middle" font-size="18" font-weight="bold" fill="#1a1a1a" font-family="serif">' + n + '</text>' +
         '<text x="20" y="43" text-anchor="middle" font-size="16" font-weight="bold" fill="#cc0000" font-family="serif">万</text>';
}

// ========== 条 ==========
function _tiaoSVG(num) {
  if (num === 1) return _birdSVG();
  var positions = BAMBOO_POS[num];
  if (!positions) return '';
  var svg = '';
  for (var i = 0; i < positions.length; i++) {
    var isRed = (num === 5 && i === 2);
    svg += _bambooStick(positions[i][0], positions[i][1], isRed);
  }
  return svg;
}

function _bambooStick(cx, cy, isRed) {
  var fill = isRed ? '#ee4444' : '#2eb84d';
  var stroke = isRed ? '#cc0000' : '#0d6b2e';
  var fill2 = isRed ? '#ff7777' : '#5bd07a';
  return '<g transform="translate(' + cx + ',' + cy + ')">' +
    '<rect x="-2.5" y="-7" width="5" height="14" rx="1.5" fill="' + fill + '" stroke="' + stroke + '" stroke-width="0.5"/>' +
    '<rect x="-2" y="-6" width="1.5" height="12" rx="0.5" fill="' + fill2 + '" opacity="0.5"/>' +
    '<line x1="-2.5" y1="-2" x2="2.5" y2="-2" stroke="' + stroke + '" stroke-width="0.6"/>' +
    '<line x1="-2.5" y1="3" x2="2.5" y2="3" stroke="' + stroke + '" stroke-width="0.6"/>' +
    '</g>';
}

function _birdSVG() {
  return '<g transform="translate(20,28)">' +
    // 尾巴
    '<path d="M5,4 L13,1 L10,6 L13,9 L5,7" fill="#2e8b3d" stroke="#1a6b2e" stroke-width="0.3"/>' +
    // 身体
    '<ellipse cx="0" cy="2" rx="7" ry="8" fill="#2e8b3d" stroke="#1a6b2e" stroke-width="0.3"/>' +
    // 肚子
    '<ellipse cx="0" cy="5" rx="4" ry="3.5" fill="#a8d88a"/>' +
    // 翅膀
    '<path d="M-5,-1 Q-2,-5 1,-1 Q-1,2 -5,-1" fill="#1a6b2e" stroke="#0d5020" stroke-width="0.3"/>' +
    // 头
    '<circle cx="2" cy="-7" r="4.5" fill="#3da655" stroke="#1a6b2e" stroke-width="0.3"/>' +
    // 冠羽
    '<path d="M0,-12 Q-1,-14 0,-15 Q1,-14 0,-12" fill="#cc4400" stroke="none"/>' +
    // 嘴
    '<path d="M5,-9 L10,-8 L5,-6" fill="#e8a020" stroke="#c08010" stroke-width="0.3"/>' +
    // 眼睛
    '<circle cx="3" cy="-8" r="1.2" fill="#000"/>' +
    '<circle cx="3.3" cy="-8.3" r="0.4" fill="#fff"/>' +
    // 脚
    '<line x1="-2" y1="10" x2="-3" y2="14" stroke="#c08010" stroke-width="0.8"/>' +
    '<line x1="2" y1="10" x2="3" y2="14" stroke="#c08010" stroke-width="0.8"/>' +
    '<line x1="-4" y1="14" x2="-1" y2="14" stroke="#c08010" stroke-width="0.8"/>' +
    '<line x1="1" y1="14" x2="4" y2="14" stroke="#c08010" stroke-width="0.8"/>' +
    '</g>';
}

// ========== 筒 ==========
function _tongSVG(num) {
  var positions = DOT_POS[num];
  if (!positions) return '';
  var svg = '';
  for (var i = 0; i < positions.length; i++) {
    var isRed = (num === 5 && i === 2);
    var r = (num === 1) ? 8 : 5;
    svg += _dot(positions[i][0], positions[i][1], r, isRed);
  }
  return svg;
}

function _dot(cx, cy, r, isRed) {
  var stroke = isRed ? '#cc0000' : '#0055aa';
  var lightFill = isRed ? '#ffe8e8' : '#e8f0ff';
  var midFill = isRed ? '#ee4444' : '#4499dd';
  var darkFill = isRed ? '#cc0000' : '#0055aa';
  return '<g transform="translate(' + cx + ',' + cy + ')">' +
    '<circle cx="0" cy="0" r="' + r + '" fill="none" stroke="' + stroke + '" stroke-width="1.2"/>' +
    '<circle cx="0" cy="0" r="' + (r - 1.5) + '" fill="' + lightFill + '"/>' +
    '<circle cx="0" cy="0" r="' + (r - 3) + '" fill="' + midFill + '"/>' +
    '<circle cx="0" cy="0" r="1" fill="' + darkFill + '"/>' +
    '</g>';
}

// ========== 字牌 ==========
function _ziSVG(idx) {
  var chars = ['\u6771', '\u5357', '\u897f', '\u5317', '\u4e2d', '\u767c', ''];
  var colors = ['#1a1a1a', '#1a1a1a', '#1a1a1a', '#1a1a1a', '#cc0000', '#008833', ''];

  if (idx === 6) {
    // 白板
    return '<rect x="10" y="14" width="20" height="26" fill="none" stroke="#3a6ab8" stroke-width="1.5" rx="1"/>' +
           '<rect x="12" y="16" width="16" height="22" fill="none" stroke="#5a8ad8" stroke-width="0.5" rx="0.5"/>' +
           '<line x1="12" y1="27" x2="28" y2="27" stroke="#5a8ad8" stroke-width="0.3"/>';
  }

  return '<text x="20" y="37" text-anchor="middle" font-size="24" font-weight="bold" fill="' + colors[idx] + '" font-family="serif">' + chars[idx] + '</text>';
}
