// ============ 龙港麻将客户端 ============

// 常量
const TILE_NAMES = [
  '1万','2万','3万','4万','5万','6万','7万','8万','9万',
  '1条','2条','3条','4条','5条','6条','7条','8条','9条',
  '1筒','2筒','3筒','4筒','5筒','6筒','7筒','8筒','9筒',
  '东','南','西','北','中','发','白'
];

// 全局状态
let ws = null;
let playerId = '';
let playerName = '';
let mySeat = -1;
let gameState = {
  roomId: '',
  players: [],
  myHand: [],
  myMelds: [],
  river: [],
  currentTurn: -1,
  remainingTiles: 0,
  selectedTile: null,
  canDiscard: false,
};

// ============ 初始化 ============
function init() {
  const savedName = localStorage.getItem('mj_name');
  if (savedName) document.getElementById('playerName').value = savedName;

  document.getElementById('btnCreate').addEventListener('click', createRoom);
  document.getElementById('btnJoin').addEventListener('click', joinRoom);
  document.getElementById('btnLeave').addEventListener('click', leaveRoom);
  document.getElementById('btnReady').addEventListener('click', toggleReady);
  document.getElementById('btnDiscard').addEventListener('click', () => {
    if (gameState.selectedTile !== null && gameState.canDiscard) {
      send({ type: 'discard', tile: gameState.selectedTile });
      gameState.selectedTile = null;
      gameState.canDiscard = false;
      updateActionBar();
    }
  });

  document.getElementById('roomCode').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') joinRoom();
  });

  connect();
}

function connect() {
  const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
  const host = location.host;
  ws = new WebSocket(`${protocol}//${host}`);

  ws.onopen = () => console.log('WebSocket connected');
  ws.onmessage = (e) => {
    try { handleMessage(JSON.parse(e.data)); }
    catch(err) { console.error('Parse error:', err); }
  };
  ws.onclose = () => {
    console.log('WebSocket disconnected, reconnecting...');
    setTimeout(connect, 2000);
  };
  ws.onerror = () => console.error('WebSocket error');
}

function send(data) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(data));
  }
}

// ============ 消息处理 ============
function handleMessage(msg) {
  switch (msg.type) {
    case 'connected':
      playerId = msg.playerId;
      break;

    case 'room_created':
      gameState.roomId = msg.roomId;
      mySeat = msg.seat;
      document.getElementById('roomCodeDisplay').textContent = msg.roomId;
      if (msg.players) updatePlayerList(msg.players);
      showView('room');
      break;

    case 'room_joined':
      gameState.roomId = msg.roomId;
      mySeat = msg.seat;
      document.getElementById('roomCodeDisplay').textContent = msg.roomId;
      updatePlayerList(msg.players);
      showView('room');
      break;

    case 'room_update':
      updatePlayerList(msg.players);
      break;

    case 'player_ready':
      updatePlayerReady(msg.seat, msg.ready);
      break;

    case 'game_start':
      handleGameStart(msg);
      break;

    case 'your_draw':
      handleDraw(msg);
      break;

    case 'draw':
      updatePlayerHandCount(msg.seat, msg.handCount);
      document.getElementById('remainingTiles').textContent = `剩余: ${msg.remainingTiles}`;
      break;

    case 'discard':
      handleDiscard(msg);
      break;

    case 'discard_self':
      // 服务端同步我出牌后的手牌
      gameState.myHand = msg.hand;
      gameState.canDiscard = false;
      gameState.selectedTile = null;
      updateSelfHand();
      updateActionBar();
      break;

    case 'meld_update':
      // 服务端同步我碰/杠/吃后的手牌和副露
      gameState.myHand = msg.hand;
      gameState.myMelds = msg.melds;
      updateSelfHand();
      break;

    case 'action_prompt':
      showActionPopup(msg);
      break;

    case 'need_discard':
      gameState.canDiscard = true;
      gameState.selectedTile = null;
      updateSelfHand();
      updateActionBar();
      break;

    case 'pong_result':
      updatePlayerHandCount(msg.seat, msg.handCount);
      break;
    case 'kong_result':
      updatePlayerHandCount(msg.seat, msg.handCount);
      document.getElementById('remainingTiles').textContent = `剩余: ${msg.remainingTiles}`;
      break;
    case 'ankong_result':
      updatePlayerHandCount(msg.seat, msg.handCount);
      document.getElementById('remainingTiles').textContent = `剩余: ${msg.remainingTiles}`;
      break;
    case 'jiakong_result':
      updatePlayerHandCount(msg.seat, msg.handCount);
      document.getElementById('remainingTiles').textContent = `剩余: ${msg.remainingTiles}`;
      break;
    case 'chi_result':
      updatePlayerHandCount(msg.seat, msg.handCount);
      break;

    case 'game_win':
      showResult(msg);
      break;
    case 'game_draw':
      showDrawResult();
      break;

    case 'room_left':
      gameState = resetGameState();
      showView('lobby');
      break;

    case 'error':
      alert(msg.message);
      break;
  }
}

// ============ 视图切换 ============
function showView(viewName) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.getElementById(viewName).classList.add('active');
}

// ============ 大厅 ============
function createRoom() {
  playerName = document.getElementById('playerName').value.trim() || '房主';
  localStorage.setItem('mj_name', playerName);
  send({ type: 'create_room', name: playerName });
}

function joinRoom() {
  playerName = document.getElementById('playerName').value.trim() || '玩家';
  localStorage.setItem('mj_name', playerName);
  const roomCode = document.getElementById('roomCode').value.trim().toUpperCase();
  if (!roomCode) { alert('请输入房间号'); return; }
  send({ type: 'join_room', roomId: roomCode, name: playerName });
}

// ============ 房间等待 ============
function leaveRoom() {
  send({ type: 'leave_room' });
}

function toggleReady() {
  const btn = document.getElementById('btnReady');
  const isReady = btn.textContent === '取消准备';
  send({ type: 'set_ready', ready: !isReady });
  btn.textContent = isReady ? '准备' : '取消准备';
  btn.classList.toggle('btn-primary', !isReady);
  btn.classList.toggle('btn-outline', isReady);
}

function updatePlayerList(players) {
  gameState.players = players;
  const list = document.getElementById('playerList');
  list.innerHTML = players.map(p => `
    <div class="player-item">
      <div class="player-seat">${p.seat + 1}</div>
      <div class="player-name-text">${p.name}</div>
      <div class="player-status ${p.ready ? 'ready' : 'waiting'}">${p.ready ? '已准备' : '等待中'}</div>
    </div>
  `).join('');
}

function updatePlayerReady(seat, ready) {
  const items = document.querySelectorAll('.player-item');
  if (items[seat]) {
    const status = items[seat].querySelector('.player-status');
    status.textContent = ready ? '已准备' : '等待中';
    status.className = `player-status ${ready ? 'ready' : 'waiting'}`;
  }
}

// ============ 游戏开始 ============
function handleGameStart(msg) {
  mySeat = msg.seat;
  gameState.myHand = msg.hand;
  gameState.myMelds = [];
  gameState.river = [];
  gameState.currentTurn = msg.currentTurn;
  gameState.remainingTiles = msg.remainingTiles;
  gameState.canDiscard = false;

  document.getElementById('gameRoomCode').textContent = gameState.roomId;
  document.getElementById('remainingTiles').textContent = `剩余: ${msg.remainingTiles}`;

  showView('game');

  renderOtherHands(msg.players);
  updateSelfHand();
  updateActionBar();
}

function getRelativeSeat(absoluteSeat) {
  return (absoluteSeat - mySeat + 4) % 4;
}

function getDisplayNames() {
  const names = ['', '', '', ''];
  for (const p of gameState.players) {
    const rel = getRelativeSeat(p.seat);
    names[rel] = p.name;
  }
  return names;
}

function renderOtherHands(players) {
  const names = getDisplayNames();
  document.getElementById('nameTop').textContent = names[2] || '----';
  document.getElementById('nameRight').textContent = names[1] || '----';
  document.getElementById('nameLeft').textContent = names[3] || '----';
  document.getElementById('nameSelf').textContent = playerName || '我';

  for (const p of players) {
    const rel = getRelativeSeat(p.seat);
    if (rel === 0) continue;
    renderFacedownHand(rel, p.handCount);
  }
}

function renderFacedownHand(relativeSeat, count) {
  const map = {
    2: { id: 'handTop', cls: 'tile-facedown' },
    1: { id: 'handRight', cls: 'tile-side' },
    3: { id: 'handLeft', cls: 'tile-side' },
  };
  const cfg = map[relativeSeat];
  if (!cfg) return;
  const container = document.getElementById(cfg.id);
  container.innerHTML = '';
  for (let i = 0; i < count; i++) {
    const div = document.createElement('div');
    div.className = `tile ${cfg.cls}`;
    container.appendChild(div);
  }
}

function updatePlayerHandCount(absoluteSeat, count) {
  const rel = getRelativeSeat(absoluteSeat);
  if (rel === 0) return;
  renderFacedownHand(rel, count);
}

// ============ 手牌渲染 ============
function createTileElement(tile, cls, clickable) {
  const div = document.createElement('div');
  div.className = 'tile ' + cls;
  div.innerHTML = tileSVG(tile);
  if (clickable) {
    div.addEventListener('click', function() { onTileClick(tile, div); });
  }
  return div;
}

function updateSelfHand() {
  const container = document.getElementById('selfHand');
  container.innerHTML = '';

  const hand = [...gameState.myHand].sort((a, b) => a - b);

  hand.forEach(tile => {
    const div = createTileElement(tile, 'tile-main', gameState.canDiscard);
    if (tile === gameState.selectedTile) {
      div.classList.add('selected');
    }
    container.appendChild(div);
  });

  updateSelfMelds();
}

function updateSelfMelds() {
  const container = document.getElementById('selfMelds');
  container.innerHTML = '';
  gameState.myMelds.forEach(m => {
    const wrapper = document.createElement('div');
    wrapper.style.display = 'flex';
    wrapper.style.gap = '1px';

    if (m.type === 'chi') {
      (m.tiles || []).forEach(t => {
        wrapper.appendChild(createTileElement(t, 'tile-meld'));
      });
    } else if (m.type === 'pong') {
      for (let i = 0; i < 3; i++) {
        wrapper.appendChild(createTileElement(m.tile, 'tile-meld'));
      }
    } else if (m.type === 'kong') {
      for (let i = 0; i < 4; i++) {
        wrapper.appendChild(createTileElement(m.tile, 'tile-meld'));
      }
    }
    container.appendChild(wrapper);
  });
}

function onTileClick(tile, element) {
  if (!gameState.canDiscard) return;

  if (gameState.selectedTile === tile) {
    gameState.selectedTile = null;
    element.classList.remove('selected');
    updateDiscardBtn();
    return;
  }

  gameState.selectedTile = tile;
  document.querySelectorAll('#selfHand .tile-main').forEach(t => t.classList.remove('selected'));
  element.classList.add('selected');
  updateDiscardBtn();
}

function updateDiscardBtn() {
  const btn = document.getElementById('btnDiscard');
  if (gameState.selectedTile !== null && gameState.canDiscard) {
    btn.disabled = false;
    btn.textContent = '出牌';
    btn.style.background = '#27ae60';
    btn.style.color = '#fff';
  } else {
    btn.disabled = true;
    btn.style.background = '#f0f0f0';
    btn.style.color = '#999';
  }
}

function updateActionBar() {
  const btn = document.getElementById('btnDiscard');
  if (gameState.canDiscard) {
    btn.disabled = true;
    btn.textContent = '请选牌';
    btn.style.background = '#f0f0f0';
    btn.style.color = '#333';
  } else {
    btn.disabled = true;
    btn.textContent = '等待中';
    btn.style.background = '#f0f0f0';
    btn.style.color = '#999';
  }
}

// ============ 摸牌 ============
function handleDraw(msg) {
  gameState.myHand = msg.hand;
  gameState.canDiscard = true;
  gameState.selectedTile = null;
  updateSelfHand();
  updateActionBar();

  // 高亮新摸的牌
  if (msg.tile !== undefined) {
    setTimeout(() => {
      const tiles = document.querySelectorAll('#selfHand .tile-main');
      const lastEl = tiles[tiles.length - 1];
      if (lastEl) {
        lastEl.style.boxShadow = '0 0 8px #27ae60';
        setTimeout(() => { if (lastEl) lastEl.style.boxShadow = ''; }, 1500);
      }
    }, 50);
  }
}

// ============ 出牌 ============
function handleDiscard(msg) {
  const rel = getRelativeSeat(msg.seat);

  gameState.river.push({ tile: msg.tile, seat: msg.seat });
  renderRiver();

  updatePlayerHandCount(msg.seat, msg.handCount);

  if (rel === 0) {
    gameState.canDiscard = false;
    gameState.selectedTile = null;
    updateActionBar();
  }
}

function renderRiver() {
  const container = document.getElementById('river');
  container.innerHTML = '';

  for (const r of gameState.river) {
    const div = createTileElement(r.tile, 'tile-river');
    container.appendChild(div);
  }
}

// ============ 操作弹窗 ============
function showActionPopup(msg) {
  const popup = document.getElementById('actionPopup');
  const content = document.getElementById('popupContent');
  const actions = msg.actions || [];
  const tile = msg.tile;

  let html = '<h3>选择操作</h3>';

  if (tile !== undefined) {
    html += '<div style="width:44px;height:56px;margin:8px auto;">' + tileSVG(tile) + '</div>';
  } else {
    html += '<p style="font-size:14px;color:#888;margin:8px 0;">你的回合</p>';
  }

  html += '<div class="action-buttons">';

  if (actions.includes('win')) {
    if (tile === undefined) {
      html += `<button class="btn btn-primary" onclick="doOwnAction('win')">自摸！</button>`;
    } else {
      html += `<button class="btn btn-primary" onclick="doAction('win')">胡！</button>`;
    }
  }
  if (actions.includes('pong')) {
    html += `<button class="btn btn-secondary" onclick="doAction('pong')">碰</button>`;
  }
  if (actions.includes('kong')) {
    html += `<button class="btn btn-secondary" onclick="doAction('kong')">杠</button>`;
  }
  if (actions.includes('chi')) {
    html += `<button class="btn btn-secondary" onclick="doAction('chi')">吃</button>`;
  }

  // 暗杠 - 显示所有可暗杠的牌
  if (actions.includes('ankong')) {
    const hand = gameState.myHand;
    const counts = {};
    hand.forEach(t => counts[t] = (counts[t] || 0) + 1);
    const ankongTiles = Object.entries(counts).filter(([, c]) => c === 4).map(([t]) => parseInt(t));
    if (ankongTiles.length > 0) {
      html += '<div style="width:100%;margin-top:8px;font-size:13px;color:#888;">暗杠：</div><div class="chi-options">';
      ankongTiles.forEach(t => {
        html += `<button class="btn btn-action" onclick="doOwnAction('ankong', ${t})">${TILE_NAMES[t]}</button>`;
      });
      html += '</div>';
    }
  }

  // 加杠
  if (actions.includes('jiakong')) {
    const jiakongTiles = [];
    gameState.myMelds.forEach(m => {
      if (m.type === 'pong' && gameState.myHand.includes(m.tile)) {
        jiakongTiles.push(m.tile);
      }
    });
    if (jiakongTiles.length > 0) {
      html += '<div style="width:100%;margin-top:8px;font-size:13px;color:#888;">加杠：</div><div class="chi-options">';
      jiakongTiles.forEach(t => {
        html += `<button class="btn btn-action" onclick="doOwnAction('jiakong', ${t})">${TILE_NAMES[t]}</button>`;
      });
      html += '</div>';
    }
  }

  // 如果只有自摸/暗杠/加杠（没有外部操作），不需要"过"按钮
  const hasExternalAction = actions.some(a => ['win','pong','kong','chi'].includes(a) && tile !== undefined);
  if (hasExternalAction || (tile === undefined && actions.length === 0)) {
    html += `<button class="btn btn-outline" onclick="doAction('pass')" style="width:auto;min-width:60px;">过</button>`;
  } else if (tile !== undefined) {
    html += `<button class="btn btn-outline" onclick="doAction('pass')" style="width:auto;min-width:60px;">过</button>`;
  } else {
    // 自摸回合的操作，如果用户不想操作，需要跳过
    html += `<button class="btn btn-outline" onclick="skipOwnAction()" style="width:auto;min-width:60px;">不出</button>`;
  }

  html += '</div>';

  content.innerHTML = html;
  popup.style.display = 'flex';
}

function doAction(action) {
  document.getElementById('actionPopup').style.display = 'none';
  send({ type: 'action', action });
}

function doOwnAction(action, tile) {
  document.getElementById('actionPopup').style.display = 'none';
  send({ type: 'own_action', action, tile });
}

function skipOwnAction() {
  document.getElementById('actionPopup').style.display = 'none';
  // 告诉服务器跳过自摸/暗杠，直接出牌
  send({ type: 'own_action', action: 'discard_now', tile: -1 });
  // 实际上服务器需要处理这个，让玩家直接出牌
  gameState.canDiscard = true;
  updateActionBar();
}

// ============ 结果 ============
function showResult(msg) {
  const popup = document.getElementById('resultPopup');
  const content = document.getElementById('resultContent');

  let html = '<h3>';
  html += msg.isSelfDraw ? '自摸！' : '胡了！';
  html += '</h3>';
  html += `<p style="font-size:18px;color:#27ae60;font-weight:600;">${msg.winnerName}</p>`;
  html += `<p style="margin:8px 0;">${msg.tai} 台</p>`;

  html += '<div style="display:flex;gap:2px;justify-content:center;flex-wrap:wrap;margin:10px 0;">';
  (msg.hand || []).sort((a, b) => a - b).forEach(t => {
    html += '<div class="tile tile-river" style="cursor:default;">' + tileSVG(t) + '</div>';
  });
  html += '</div>';

  html += '<div class="action-buttons">';
  html += `<button class="btn btn-primary" onclick="backToRoom()">返回房间</button>`;
  html += '</div>';

  content.innerHTML = html;
  popup.style.display = 'flex';
}

function showDrawResult() {
  const popup = document.getElementById('resultPopup');
  const content = document.getElementById('resultContent');
  content.innerHTML = `
    <h3>荒庄</h3>
    <p>牌已摸完，无人胡牌</p>
    <div class="action-buttons">
      <button class="btn btn-primary" onclick="backToRoom()">返回房间</button>
    </div>
  `;
  popup.style.display = 'flex';
}

function backToRoom() {
  document.getElementById('resultPopup').style.display = 'none';
  gameState = resetGameState();
  showView('room');
}

function resetGameState() {
  return {
    roomId: '',
    players: [],
    myHand: [],
    myMelds: [],
    river: [],
    currentTurn: -1,
    remainingTiles: 0,
    selectedTile: null,
    canDiscard: false,
  };
}

// ============ 启动 ============
document.addEventListener('DOMContentLoaded', init);
